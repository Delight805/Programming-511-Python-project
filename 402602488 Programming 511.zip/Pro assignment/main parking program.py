from pricing import *
from data import *
from reports import *
from datetime import datetime

users = load_data("users.json")
parking_records = load_data("parking_records.json")
payments = load_data("payments.json")


#Malls

gateway_umhlanga = Mall(
    "Gateway Theatre of Shopping",
    250,
    FlatRatePricing(15)
) 

pavillion_westville = Mall(
    "Pavilion Shopping Centre",
    180,
    HourlyPricing(10)
)

lalucia_durban = Mall(
    "lalucia Mall",
    150,
    CappedHourlyPricing(12,60)
)

malls = [gateway_umhlanga, pavillion_westville, lalucia_durban]


#functions
def save_all():
    save_data("users.json", users)
    save_data("parking_records.json", parking_records)
    save_data("payments.json", payments)
    
    
def find_user(username, password):
    for user in users:
        if user["username"] == username and user["password"] == password:
            return user
    return None
    
#User Registration Process

def register():
    
    print("\n-------------Register--------------")
    
    username = input("Enter your name: ")
    password = input("Enter your password: ")
    
    print("\n")
    print("1. Customer")
    print("2.Administrator")
    print("3.Owner or Shareholder")
    
    
    capacity_choice = input("Select your choice of capacity: ")
    
    if capacity_choice == "1":
        capacity = "customer"
    
    elif capacity_choice == "2":
        capacity = "administrator"
        
    elif capacity_choice == "3":
        capacity = "owner_or_shareholder"
        
    else:
        print("Invalid capacity")
        return 
    
    user = {
        "username": username,
        "password": password,
        "capacity": capacity
    }
    
    users.append(user)
    save_all()

    print("Registration successful")

#User Login Process

def login():
    print("\n-----------------Login-------------------")
    
    username = input("Username: ")
    password = input("Password: ")
    
    user = find_user(username, password)

    if user:
        print("Login successful")
        return user
    else:
        print("Invalid credentials")
        return None

#Mall Selection 

def select_mall():
    print("\n----------Select Mall----------")
    
    for i, mall in enumerate(malls):
        print(f"{i+1}. {mall.name}")
        
    choice = int(input("Choose the mall: "))
    return malls[choice - 1]
        
#Vehicle entry

def vehicle_entry(user):
    mall = select_mall()
    
    current_count = 0
    
    for record in parking_records:
        if record["mall"] == mall.name and record["status"] == "In":
            current_count +=1
            
    if current_count >= mall.capacity:
        print("Parking is Full")
        return
        
    vehicle_plate = input("Enter your vehicle plate number: ")
    
    record = {
        "username":user["username"],
        "mall": mall.name,
        "plate": vehicle_plate,
        "time_of_entry": str(datetime.now()),
        "time_of_exit": "",
        "duration": 0,
        "fee": 0,
        "paid":  False,
        "status": "In"
       
  }
    parking_records.append(record)
    save_all()
    
    print("Vehicle entered has entered succesfully")
  
#Vehicle exit

def vehicle_exit(user):
    vehicle_plate = input("Enter your vehicle plate number: ")

    for record in parking_records:
        if record ["plate"] == vehicle_plate and record["status"]== "In":
        
            time_of_exit = datetime.now()
            time_of_entry = datetime.fromisoformat(record["time_of_entry"])
            
            duration_hours = (time_of_exit - time_of_entry).total_seconds()/3600
            
            name_of_mall = record["mall"]
            
            selected_mall = None
            for mall in malls:
                if mall.name == record["mall"]:
                    selected_mall = mall
            
            fee = selected_mall.pricing.calculate_fee(duration_hours)
            
            record["time_of_exit"] = str(time_of_exit)
            record["total_duration"] = duration_hours
            record["fee"] = fee
            record["paid"] = False
            record["status"] = "Out"
            
            print("Mall: ", name_of_mall)
            print("Duration: " , duration_hours)
            print("Type of Pricing: " , (selected_mall.pricing.get_type()))
            print(f"The Amount Due:  R{fee}")
            
            payment_method = input("Pay now? (yes/no): ")
            
            if payment_method.lower() == "yes":
                
                payment = {
                   "username": user["username"],
                   "mall": name_of_mall,
                   "plate": vehicle_plate,
                   "amount": fee,
                   "time_of_payment": str(datetime.now())
              
               }
                payments.append(payment)
                
                print("\n----------------- Payment Receipt -----------------")
                print("Customer: ", user["username"])
                print("Mall: ", record["plate"])
                print("Amount Paid: R" , fee)
                print("Payment successful")
                print("-------------------------------------------------------")
            
            save_all()
            return
    
    print("Vehicle not found")
    
#Parking status

def current_parking_status(user):
    print("\n -----------------Current Parking Status-----------------")
    
    found = False
    
    for record in parking_records:
        if (record["username"] == user["username"] and 
            record["status"] == "In"):
            
            entry_time = datetime.fromisoformat(
                record["time_of_entry"]
            )
            
            duration = (
                datetime.now() - entry_time
            ).total_seconds()/3600
            
            print(f"Mall:{record['mall']}")
            print(f"Vehicle: {record['plate']}")  
            print(f"Entry time: {record['time_of_entry']}")
            print(f"Current Duration: {round(duration, 2)} hours")
                        
            found = True
            
    if not found:
        print("You currently do not have any vehicle parked")   
        
#Outstanding charges

def outstanding_charges(user):

    print("\n----------------Outstanding Charges----------------")          
    
    found = False
    total_due = 0
    
    for record in parking_records:
        if(
            record["username"] == user["username"]
            and record ["status"] == "Out"
            and record.get("paid" , False) == False
            and record["fee"] >0
                
        ):
 
            print("\nMall:", record ["mall"])
            print("Vehicle:" , record["plate"])
            print("Duration:" , (record["duration"]))
            print("Amount Due: R", record["fee"])
            
            total_due += record["fee"]
            found = True
            
    if found:
        print("\n-----------------------------------")
        print(f"Your Total Outstanding Amount is : R{total_due}")
        
    else:
        print("You have no outstanding charges.")     
#History

def view_history(user):
    print("\n--------------Parking History-----------------")
    
    for record in parking_records:
        if record["username"] ==user["username"]:
            print(record)
            
            
#Menues

def customer_menu(user):
    while True:
        
        print("\n----------------- Customer Menu----------------")
        print("1. Vehicle Entry")
        print("2. Current parking status")
        print("3. Vehicle Exit")
        print("4. View History")
        print("5. View Outstanding Charges")
        print("6. Logout")
        
        choice = input("Choose between choice 1-6:")
        
        if choice == "1":
            vehicle_entry(user)
            
        elif choice =="2":
            current_parking_status(user)
            
        elif choice == "3":
            vehicle_exit(user)
            
        elif choice == "4":
            view_history(user)
            
        elif choice == "5":
            outstanding_charges(user)
            
        elif choice == "6":
            print("Logging out")
            
            break

def adminstrator_menu(user):
    while True:
        print("\n----------------Administrantor Menu-----------------")
        print("1. View Currently Parked Vehicles")
        print("2. View Parking Capacity")
        print("3. Logout")
        
        choice=input("Choose between choice 1-3:")
      
        
        if choice == "1":
            for record in parking_records:
                if record["status"] == "In":
                    print(record)
                    
        elif choice == "2":
            for mall in malls:
                count = 0
                
                for record in parking_records:
                    if record ["mall"] == mall.name and record ["status"] == "In":
                        count += 1
                        
                print(f"{mall.name}: {count}/{mall.capacity}")
                
        elif choice == "3":
            print("Logging out")
            break
        
def owner_menu(user):
    while True:
        print("\n-------------------Owner Menu-------------------")
        print("1. View Mall Reports")
        print("2. Revenue Comparison between malls")
        print("3. Logout")
        
        choice = input("Choose between choice 1-3")
        
        if choice == "1":
            mall_reports(malls, parking_records, payments)

        elif choice == "2":
            revenue_comparison(malls, payments)
            
        elif choice == "3":
            print("Logging out")
            break
        
        
while True:
    print("\n-----------------KZN Mall Parking System------------------")
    print("1. Register")
    print("2. Login")
    print("3. Exit")
    
    option = input("Choose from option 1-3")
    
    if option == "1":
        register()
        
    elif option =="2":
        user = login()
        
        if user:
            if user ["capacity"] == "customer":
                customer_menu(user)
                
            elif user["capacity"] == "administrator":
                adminstrator_menu(user)
                
            elif user["capacity"] == "owner_or_shareholder":
                owner_menu(user)
                
    elif option == "3":
        print("Goodbye")
        break
    
    else:
        print("Invalid Choice")
                
                   



