import math

class PricingStrategy:
    
    def calculate_fee(self, hours):
        pass
    
    def get_type(self):
        pass
    
    
class FlatRatePricing(PricingStrategy):
    
    def __init__(self, fee):
        self.fee = fee
        
    def calculate_fee(self, hours):
        return self.fee
    
    def get_type(self):
        return "flat Rate"
    
class HourlyPricing(PricingStrategy):
    def __init__(self, rate):
        self.rate = rate
        
    def calculate_fee(self, hours):
        return math.ceil(hours) * self.rate
    
    def get_type(self):
        return "Hourly Rate"


class CappedHourlyPricing(PricingStrategy):
    
    def __init__(self, rate, cap):
        self.rate = rate
        self.cap = cap
        
    def calculate_fee(self, hours):
    
        fee = math.ceil(hours) * self.rate
        return min(fee, self.cap)
    
    def get_type(self):
        return"Hourly Rate With Cap"
        
        
class Mall:
    
    def __init__(self, name, capacity, pricing):
        
        self.name = name
        self.capacity = capacity
        self.pricing = pricing