from datetime import datetime
import json
import math
import os
from getpass import getpass


class PricingStrategy:
    
    def calculate_fee(self, hours):
        pass
    
    def get get_type(self):
    
        pass
    
    
class FlateRatePricing (PricingStrategy):
    
    def __init__(self, fee):
        self.fee = fee
        
    def calculate_fee(self, hours):
        return self.fee
    
    def get_type(self):
        return "flat Rate"
    
class HourlyPricing(PricingStragety):
    
    def __init__(self, rate):
        self.rate = rate
        
def calculate_fee(self, hours):
    return math.ceil(hours) * self.rate

def get_type(self):
    return "Hourly Rate"


class CappedHourlyPricng(PricingStragety):
    
    def __init__(self, rate, cap):
        self.rate = rate
        self.cap = cap
        
    def calculate_fee(self, hours):
    
        fee = math.ceil(hours) * self.rate
        return min(fee, self.cap)
    
    def get_type(self):
        return"Hourly With Daily Cap"
        
        
class Mall:
    
    def __init__(self, name, capacity, pricing):
        
        self.name = name
        self.capacity = capacity
        self. pricing = pricing
    


    
user = {
      "username": username,
      "password": password,
      "capacity": capacity   
        
    }   
users.append(user)
save_all()      


#Malls

gateway_umhlanga = Mall(
    "Gateway Theatre of Shopping",
    250,
    FlatRatePricing(15)
) 

pavillion_wistville = Mall(
    "Pavilion Shopping Centre",
    180,
    HourlyPricing(10)
    )
