def mall_reports(malls, parking_records, payments):
    print("\n------------ Mall Reports-------------")
    
    for mall in malls:
        vehicle_count = 0
        total_duration = 0
        total_revenue = 0 
        
        for record in parking_records:
            
            if record["mall"] == mall.name:
                vehicle_count += 1
                total_duration += record["duration"]
                
        for payment in payments:
            
            if payment["mall"] == mall.name:
                total_revenue += payment["amount"]
                       
        if vehicle_count  > 0:
            average_duration = total_duration/vehicle_count
            print("Hourly duration :" , round(average_duration, 5))
            
        else:
            average_duration = 0
            
        print("-------------------------------------------")    
        print(f"\nMall: {mall.name}")
        print(f"Parking Capacity: {mall.capacity}")
        print(f"Number of Vehicles Parked: {vehicle_count}")
        print(f"Total Revenue of {mall.name}: R{total_revenue}")
        
def revenue_comparison(malls, payments):
    print("\n---------------Revenue Comparison-----------------")
    
    highest_revenue= 0 
    highest_mall = None
    
    for mall in malls:
        revenue = 0
        for payment in payments:
            
            if payment["mall"] == mall.name:
                revenue+= payment["amount"]
                
        print(f"{mall.name}:  R{revenue}")
        
        if revenue > highest_revenue:
            
            highest_revenue = revenue
            highest_mall = mall.name
            
    print("\n------------------Revenue Summary-----------------")
    if highest_mall:
        print(f"Mall with the Highest Revenue is: {highest_mall} R{highest_revenue}")
                  
    else:
        print("No payments have been recorded yet.")
    